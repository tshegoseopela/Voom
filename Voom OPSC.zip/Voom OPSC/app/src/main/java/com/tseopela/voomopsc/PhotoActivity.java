package com.tseopela.voomopsc;


//CODE ATTRIBUTION
//        this code is taken from OPSC Module Manual
//        Open-Source Coding (Introduction) Module Manual 2022
//        First Edition 2020

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PhotoActivity extends AppCompatActivity {

    //creating the controls
    private FloatingActionButton fabImage,fabUpload;
    private ImageView imgCamera;
    private static final int REQUEST_IMAGE_CAPTURE = 0;
    private static final int REQUEST_IMAGE_CAPTURE_PERMISSIONS = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        //linking the controls to the components
        fabImage = findViewById(R.id.fabImage);
        fabUpload = findViewById(R.id.fabUpload);
        imgCamera = findViewById(R.id.imgCamera);

        //onclick-listener:enable the user to take an image
        fabImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //check if permission is granted
                if(ActivityCompat.checkSelfPermission(PhotoActivity.this,
                        Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                {
                    final String [] permission = {Manifest.permission.CAMERA};
                    //request permission - this is asynchronous
                    ActivityCompat.requestPermissions(PhotoActivity.this,
                            permission,REQUEST_IMAGE_CAPTURE_PERMISSIONS);
                }else{
                    takePhoto(); //permission granted - photo to be taken
                }
            }
        });

    }

    //get notified when the result returns
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //check if we are receiving the result from the right request and if the user cancelled or not
        if(requestCode == REQUEST_IMAGE_CAPTURE && data != null)
        {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgCamera.setImageBitmap(bitmap);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == REQUEST_IMAGE_CAPTURE_PERMISSIONS &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED)
        {
            //permission granted to use camera
            takePhoto();
        }
    }

    //enables the user to take a photo
    public void takePhoto()
    {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i,REQUEST_IMAGE_CAPTURE);
    }

}