package com.tseopela.voomopsc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity{

    //creating the controls
    private Button btnNewItem;
    private EditText edType,edDescription,edCategory,edGoal;
    private FloatingActionButton fabDate,fabImage;

    //action button
    private Parts parts = new Parts();
    private String orderedValue;

    //Firebase connection + reference
    FirebaseDatabase Fdatabase = FirebaseDatabase.getInstance();
    DatabaseReference voomRef = Fdatabase.getReference("parts");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //linking the controls
        fabDate=findViewById(R.id.fabDate);
        fabImage=findViewById(R.id.fabImage);
        btnNewItem=findViewById(R.id.btnNewItem);
        edType=findViewById(R.id.edType);
        edDescription=findViewById(R.id.edDescription);
        edCategory=findViewById(R.id.edCategory);
        edGoal=findViewById(R.id.edGoal);

        orderedValue = getIntent().getStringExtra("parts");

        //onclick-listener: Adding Date
        fabDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //creating a calender object
                Calendar datePicker = Calendar.getInstance();
                int year = datePicker.get(Calendar.YEAR); //display the year
                int month = datePicker.get(Calendar.MONTH); //display the month
                int day = datePicker.get(Calendar.DAY_OF_MONTH); //display the day

                //display datePicker Dialog//
                //creating instance of DatePicker dialog
                DatePickerDialog orderDatePicker =
                        new DatePickerDialog(AddActivity.this,
                                android.R.style.Theme_Light_Panel, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                                parts.setDate(year+"-"+month+"-"+dayOfMonth); //setting order date
                            }
                        },year,month,day); //returning the date in the format "year-month-day"
                orderDatePicker.show();
            }
        });

        //onclick-listener: navigate to Photo Activity to take image and store it
        fabImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {   // ---current class  ---navigating to class
               startActivity(new Intent(AddActivity.this,PhotoActivity.class));
            }
        });

        //onclick-listener: Adding item to Firebase
        btnNewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //enabling the user to enter details of item
              String itemType = edType.getText().toString();
              String itemDescription = edDescription.getText().toString();
              String itemCategory = edCategory.getText().toString();
              String itemGoal = edGoal.getText().toString();

                //checking if the user has filled all fields - name/cell/order date
                if(!TextUtils.isEmpty(itemCategory) && !TextUtils.isEmpty(itemType) &&
                   !TextUtils.isEmpty(itemDescription) && !TextUtils.isEmpty(parts.getDate()))
                {
                    //setting the Parts attributes
                    parts.setType(itemType);
                    parts.setDescription(itemDescription);
                    parts.setCategory(itemCategory);
                    parts.setGoal(itemGoal);

                    //write to the database
                    voomRef.push().setValue(parts); //sending the whole object
                }else{
                    //if they haven't filled all the fields
                    Toast.makeText(AddActivity.this,
                            "Please enter all the fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}