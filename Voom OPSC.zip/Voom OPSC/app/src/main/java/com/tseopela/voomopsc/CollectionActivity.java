package com.tseopela.voomopsc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CollectionActivity extends AppCompatActivity {

    //creating the controls
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference voomRef = database.getReference("parts");
    ListView lstHistory;
    List<String> itemList;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection);

        itemList = new ArrayList<>();
        lstHistory = findViewById(R.id.lstvHistory);

        //linking to the realtime database
        voomRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot pulledItem: snapshot.getChildren())
                {
                    Parts order = pulledItem.getValue(Parts.class);
                    itemList.add(order.toString());
                }
                //creating an adapter to display the data
                arrayAdapter = new ArrayAdapter<String>(CollectionActivity.this,
                        android.R.layout.simple_list_item_1,itemList);
                lstHistory.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CollectionActivity.this, "Error loading",
                        Toast.LENGTH_SHORT).show();
            }
        });

    }


}