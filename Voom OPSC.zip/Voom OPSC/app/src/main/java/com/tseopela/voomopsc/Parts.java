package com.tseopela.voomopsc;

import android.media.Image;

//class that will store the attributes of each part + constructors
public class Parts
{
    //attributes for the auto-part
    private String category;
    private String type;
    private String description;
    private String date;
    private String goal;

    //empty default constructor
    public Parts() {
    }

    //constructor with all attributes
    public Parts(String category, String type, String description, String date , String goal) {
        this.category = category;
        this.type = type;
        this.description = description;
        this.date = date;
        this.goal = goal;
    }

    //getters and setters for all attributes
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    //toString constructor to display a list of the items
    @Override
    public String toString() {
         return "Auto-Part Items" + '\n' +
                 "================" + '\n' +
                "Category: " + category + '\n' +
                "Type: " + type + '\n' +
                "Description: " + description + '\n' +
                "Goal for item: " + goal + '\n' +
                "Date Acquired: " + date;
    }
}
