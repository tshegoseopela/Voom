package com.tseopela.voomopsc;

//importing context and intent
 import android.content.Context;
 import android.content.Intent;
 import android.os.Bundle;

public class IntentHelper
{
    //intent class for sharing information
    //open intent to receive data
    public static void openIntent(Context context,String parts,Class passTo)
    {
        //instantiating the intent - the context and the class passing information to
        Intent i = new Intent(context,passTo);
        i.putExtra("parts",parts); //passing the string
        context.startActivity(i); //starting the activity
    }

    public static void shareIntent(Context context,String order)
    {
        //creating an instance of the intent
        Intent sendIntent = new Intent();

        //sent intent action
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT,order);

        //specifying the type of text
        sendIntent.setType("text/plain");
        //sendIntent.setType("image");

        //enabling the user to select an item
        Intent shareIntent = Intent.createChooser(sendIntent,null);
        context.startActivity(shareIntent); //api import
    }

    //overloading the shareIntent
    static void shareIntent(Context context, String productName,String customerName,String customerCell)
    {
        Intent sendIntent = new Intent(); //creating an instance of the intent
        sendIntent.setAction(Intent.ACTION_SEND);

        //creating a bundle to send order object
        Bundle shareOrderDetails = new Bundle();
        shareOrderDetails.putString("item category",productName);
        shareOrderDetails.putString("item type",customerName);
        shareOrderDetails.putString("item description",customerCell);
        shareOrderDetails.putString("item date",customerCell);
        shareOrderDetails.putString("item image",customerCell);

        sendIntent.putExtra(Intent.EXTRA_TEXT,shareOrderDetails); //sharing the entire bundle
        sendIntent.setType("text/plain"); //setting the type

        //enabling the user to select an item
        Intent shareIntent =  Intent.createChooser(sendIntent,null);
        context.startActivity(shareIntent);

    }

}
